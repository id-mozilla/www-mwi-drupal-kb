Themes found here need to be moved to one of Drupal's themes directories.

It's not common practice to include themes within a module directory
as has been done here.  However, the themes are so closely linked to
the Drupal for Facebook modules that it seemed appropriate.

